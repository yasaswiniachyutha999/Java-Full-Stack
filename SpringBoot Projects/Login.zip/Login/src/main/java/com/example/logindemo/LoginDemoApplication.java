package com.example.logindemo;

import com.example.logindemo.model.User;
import com.example.logindemo.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class LoginDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(LoginDemoApplication.class, args);
    }

    @Bean
    CommandLineRunner run(UserRepository repo) {
        return args -> {
            if (repo.findByUsername("testuser") == null) {
                User user = new User();
                user.setUsername("testuser");
                user.setPassword("pass123");
                repo.save(user);
                System.out.println("✅ testuser added");
            }
        };
    }
}
