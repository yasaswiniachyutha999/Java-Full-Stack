package com.example.logindemo.controller;

import com.example.logindemo.model.User;
import com.example.logindemo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class LoginController {

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password) {
        User user = userRepository.findByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            return "Login Successful!";
        } else {
            return "Invalid credentials.";
        }
    }

    @PutMapping("/reset-password")
    public String resetPassword(@RequestParam String username, @RequestParam String newPassword) {
        User user = userRepository.findByUsername(username);
        if (user != null) {
            user.setPassword(newPassword);
            userRepository.save(user);
            return "Password updated successfully!";
        } else {
            return "User not found.";
        }
    }
}
